const baseUrl = window.location.origin;
window.XH_ROUTER_URL = {
    demoPage: `${baseUrl}/main.html#/demo`
}